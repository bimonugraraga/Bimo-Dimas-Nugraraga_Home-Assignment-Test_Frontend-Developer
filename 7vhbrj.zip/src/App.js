import "./styles.scss";
import icon from "./gibox_digital.png";

export default function App() {
  return (
    <div className="App">
      <img src={icon} alt="icon" />
    </div>
  );
}
